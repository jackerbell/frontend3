
$(document).ready(function(){
    //DOM이 완성되면 실행된다.
    menu()
    slide()
    slide_move()
   // tab()
    popup()
    tab_advanced()
})

function menu(){
    $('.gnb>li').hover(
        // mouseover.
        function(){
            console.log('mouseover')
            $('.lnb').stop().slideDown()// stop()이 없을 경우 동작이 중첩되어 나타남.. 
        },                              // 깔끔한 작업 수행을 위해서 애니메이션에서는 stop함수가 필수적임.. 
            //ㅡchaining 기법,stop 을 사용해서 이전 애니메이션을 중지시킴..
        // mouseout
        function(){
            console.log('mouseout')
            $('.lnb').stop().slideUp()
        }
    )
}
function slide(){
    setInterval(slide_move,3000)
    //setInterval .. 3s 마다 슬라이드 애니메이션 실행
}
var animateTime = 0;
function slide_move(){
    //animate
    if(animateTime<-600) animateTime = 0
    $('#slide-contents').animate({'top':animateTime},400,'swing')
    animateTime -= 300
}
function tab_advanced(){
    $('.tab_btn>a').click(function(){
        //alert('anchor click!')
        var index=$(this).index() // this ..이벤트 일어난 곳의 주소, 위치 index-몇번째 요소인지 알려주는 함수
        //alert(index)                      // 문제 해결의 핵심은 index() 적용.
        $(".tab_contents>div").hide() // 모두 숨기게 됨.. 
        $(".tab_contents>div").eq(index).show() // 모두 숨기게 됨.. 
    })
}
/*function tab(){
    //tab_btn밑에 앵커중에서 0번째 (첫번째 탭 버튼)
    $(".tab_btn>a").eq(0).click(function(){
        $(".tab_contents>div").eq(1).hide()
        $(".tab_contents>div").eq(0).show()
    })
    //tab_btn밑에 앵커중에서 1번째 (두번째 탭 버튼)
    $(".tab_btn>a").eq(1).click(function(){
        $(".tab_contents>div").eq(0).hide()
        $(".tab_contents>div").eq(1).show()
    })
}*/
function popup(){
    //공지사항 첫번째 글 클릭하면 팝업창 보여준다.
    $(".pop").click(function(){
        $("#popup").show()
    })
    //팝업창 닫기 버튼 클릭하면 팝업창 닫는다.(숨긴다.)
    $("#closeBtn").click(function(){
        $("#popup").hide()
    })
}