
$(document).ready(function(){
    //DOM이 완성되면 실행된다.
    menu()
    slide()
    slide_init()
   // tab()
    popup()
})

function menu(){
    var idx = 0
    $('.gnb>li').hover(
    function(){
        idx=$(this).index()
        console.log(idx)
        $('.gnb>li').eq(idx).find('.lnb').stop().slideDown()
        //gnb 하위 리스트에 대해 선택한 idx순서의 lnb를 찾아 이벤트 실행 
    },
    function(){
        idx=$(this).index()
        console.log(idx)
        $('.gnb>li').eq(idx).find('.lnb').stop().slideUp()

    })
}

function slide(){
    setInterval(slide_fade,3000)
    //setInterval .. 3s 마다 슬라이드 애니메이션 실행
}

function slide_init(){
    for(var i = 0; i <= 2; i++){
        $('#slide_contents>img').eq(i).hide()
    }
    $('#slide_contents>img').eq(0).show()
}
var animateTime = 0;
var idx = 0
function slide_fade(){
        $('#slide_contents>img').eq(idx).fadeOut(1000)  
        if(idx>=2) idx = -1   
        $('#slide_contents>img').eq(idx+1).fadeIn(1000)
        idx += 1
}

function popup(){
    //공지사항 첫번째 글 클릭하면 팝업창 보여준다.
    $(".pop").click(function(){
        $("#popup").show()
    })
    //팝업창 닫기 버튼 클릭하면 팝업창 닫는다.(숨긴다.)
    $("#closeBtn").click(function(){
        $("#popup").hide()
    })
}

function tab(){
    var index
    $('.tab_btn>a').click(function(){
        //alert('anchor click!')
        index=$(this).index() // this ..이벤트 일어난 곳의 주소, 위치 index-몇번째 요소인지 알려주는 함수
        //alert(index)                      // 문제 해결의 핵심은 index() 적용.
        $(".tab_contents>div").hide() // 모두 숨기게 됨.. 
        $(".tab_contents>div").eq(index).show() // 모두 숨기게 됨.. 
    })
}