$(document).ready(function(){
    menu()
    slide_move()
    slide()
    popup()
})

function menu(){
    $('.gnb>li').hover(
        function(){
            $('.left_bg').stop().slideDown()
            $('.lnb').stop().slideDown()
            $('.right_bg').stop().slideDown()

        },
        function(){
            $('.left_bg').stop().slideUp()
            $('.lnb').stop().slideUp()
            $('.right_bg').stop().slideUp()
        }
    )
}
var animateTime = 0
function slide_move(){
    if(animateTime<-2400) animateTime = 0
    $('#slide_contents').animate({'left':animateTime},400,'swing')
    if(animateTime>=-2400)animateTime -= 1200
}

function slide(){
    setInterval(slide_move,3000)
}

function popup(){
    $('#pop').click(function(){
        $('#popup').show()
    })
    $('#close_btn').click(function(){
        $('#popup').hide()
    })
}
