
$(document).ready(function(){
    //DOM이 완성되면 실행된다.
    menu()
    slide()
    //tab()
    tab_advanced()//개선된 탭메뉴 함수
    popup()
})

function menu(){
    $(".gnb>li").hover(
        //mouseover
        function(){
            console.log('mouseover')
            $(".lnb").stop().slideDown()
            //chainging기법, stop을 사용해서 이전 애니메이션 중지
            //->드랍다운 메뉴가 자연스럽게 된다.
            //stop을 안쓰면 애니메이션이 큐에 쌓여서...중첩...
        },
        //mouseout
        function(){
            console.log('mouseout')
            $(".lnb").stop().slideUp()
        }
    )
}
function slide(){
    setInterval(slide_move,3000)
    //3초마다 slide_movie함수 실행
    //3초마다 이미지가 움직여서...슬라이드처럼 보인다.
}
//animate, setInterval
var curTop=0//전역변수
function slide_move(){
    //animate : 0,-300,-600
    $("#slide_contents").animate({"top":curTop},400,'swing')
    curTop=curTop-300
    if(curTop==-900){
        curTop=0
    }
}

function tab(){
    //tab_btn밑에 앵커중에서 0번째 (첫번째 탭 버튼)
    $(".tab_btn>a").eq(0).click(function(){
        $(".tab_contents>div").eq(1).hide()
        $(".tab_contents>div").eq(0).show()
    })
    //tab_btn밑에 앵커중에서 1번째 (두번째 탭 버튼)
    $(".tab_btn>a").eq(1).click(function(){
        $(".tab_contents>div").eq(0).hide()
        $(".tab_contents>div").eq(1).show()
    })  
}

function tab_advanced(){
    $(".tab_btn>a").click(function(){
        //alert("anchor click!")
        var index=$(this).index()
        //$(this)-이벤트 일어난곳의 주소
        //index-몇번째 요소인가
        //alert(index)//0,1 
        $(".tab_contents>div").hide()//다숨긴다.
        $(".tab_contents>div").eq(index).show()
        //index번째만 보여준다.
    })
}

function popup(){
    //공지사항 첫번째 글 클릭하면 팝업창 보여준다.
    $(".pop").click(function(){
        $("#popup").show()
    })
    //팝업창 닫기 버튼 클릭하면 팝업창 닫는다.(숨긴다.)
    $("#closeBtn").click(function(){
        $("#popup").hide()
    })
}