$(document).ready(function(){
    //DOM이 완성되면 실행된다. 
    menu()
    slide()
    tab()
    popup()
})

function menu(){

}
function slide(){

}
function tab(){
    //tab-btn 밑에 앵커중에서 0번째 (첫번째 탭 버튼)
    $('.tab-btn > a').eq(0).click(function(){
        $('.tab_contents>div').eq(1).hide()    
        $('.tab_contents>div').eq(0).show()    
    })
    $('.tab-btn > a').eq(1).click(function(){
        $('.tab_contents>div').eq(1).show()    
        $('.tab_contents>div').eq(0).hide() 
    })
}
function popup(){
    //공지사항 첫번째 글 클릭하면 팝업창 보여줌.. 
    $('.pop').click(function(){
        $('#popup').show()
    })
    //팝업창 닫기 버튼 클릭하면 팝업창 닫음.. 
    $('#closeBtn').click(function(){
        $('#popup').hide()
    })
}