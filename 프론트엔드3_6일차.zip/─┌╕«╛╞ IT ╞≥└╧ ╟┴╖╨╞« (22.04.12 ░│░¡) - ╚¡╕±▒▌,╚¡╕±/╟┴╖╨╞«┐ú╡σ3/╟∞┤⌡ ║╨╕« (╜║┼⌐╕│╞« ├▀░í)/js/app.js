
function header_detach(){
    $(window).scroll(function(){//scroll이벤트가 발생하면 익명함수 실행
        var sc_top=$(this).scrollTop();//스크롤 탑 값을 가져와서
        console.log(sc_top)//확인하고
        if(sc_top>=464){//스크롤 탑 값이 464이상이면?
            $('header').addClass('fixed')//fixed클래스를 추가해서
            //화면에 고정되게하고
        }else{//464미만...위로 올라갈때
            $('header').removeClass('fixed')//fixed클래스 제거해서
            //화면 원상복귀
        }
    })
}

$(document).ready(function(){
    header_detach()//호출
})