$(document).ready(function(){
    getData()
})

function getData(){
    $.get('https://yts.mx/api/v2/list_movies.json',function(response){
        console.log(response)//callback에 응답을 찍으면 자동으로 JSON으로 변환해줌..
    })
}