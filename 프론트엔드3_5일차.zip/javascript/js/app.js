 function addList() {
        var contents = document.querySelector(".text-basic");
        if (!contents.value) {
          alert("내용을 입력해주세요.");
          contents.focus(); // input 창에 커서가 깜빡거림. 
          return false;
        }
        var tr = document.createElement("tr"); //table row 생성
        var input = document.createElement("input"); // input 생성
        input.setAttribute("type", "checkbox"); // input에 체크박스 타입을 추가
        input.setAttribute("class", "btn-chk"); // input에 btn-chk라는 클래스를 추가
        var td01 = document.createElement("td"); // 첫번째 td 항목 추가
        td01.appendChild(input); // 생성한 첫번째 td 항목에 위에서 설정한 input 박스 집어넣음.. 
        tr.appendChild(td01); // tr에 위에서 설정한 첫번째 td 항목을 후미에 추가함.. 
        var td02 = document.createElement("td"); // 두번째 td 항목 추가
        td02.innerHTML = contents.value; // 두번째 td 항목에 입력항목을 추가. input tag 기준으로 입력하는 text는 value!!
        tr.appendChild(td02);// tr에 두 번째 td 추가.. 
        document.getElementById("listBody").appendChild(tr);// tbody의 후미에 tr 추가 
        contents.value = ""; // 입력 후 입력창 비우기
        contents.focus(); // 커서
      }

      function delAllEle() {
        var list = document.getElementById("listBody");// tbody 할일 목록에 접근 
        while ( list.hasChildNodes() ){
          list.removeChild( list.firstChild );       
        }

      }

      function delLastEle() {
        var body = document.getElementById("listBody");
        var list = document.querySelectorAll("#listBody > tr");
        if (list.length > 0) {
          var liLen = list.length - 1;
          body.removeChild(list[liLen]);
        } else {
          alert("삭제할 항목이 없습니다.");
          return false;
        }
      }

      function delSelected() {
        var body = document.getElementById("listBody");
        var chkbox = document.querySelectorAll("#listBody .btn-chk");
        for (var i in chkbox) {
          if (chkbox[i].nodeType == 1 && chkbox[i].checked == true) {
            body.removeChild(chkbox[i].parentNode.parentNode);
          }
        }
      }