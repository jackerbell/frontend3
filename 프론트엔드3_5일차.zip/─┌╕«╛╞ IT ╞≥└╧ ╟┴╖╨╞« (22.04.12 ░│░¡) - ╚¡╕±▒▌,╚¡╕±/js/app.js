function header_detach(){
    $(window).on("scroll",function(){
        var sc_top=parseInt($(this).scrollTop()); //scroll 되면 top 좌표를 알려줌 여기서 스크롤 탑은 내장객체..1
        console.log(sc_top) // 콘솔로 적절한 위치확인..2
        if(sc_top>=464){ // 조건(위치)에 따라 클래스 효과를 적용시키기..3
            $('header').addClass('fixed')
        }
        else{
            $('header').removeClass('fixed')
        }
    })
}

$(document).ready(function(){ // 
    header_detach()
})